import React, { useState } from 'react';
import {
  User,
  KeyRound,
  Eye,
  EyeOff,
  LogIn,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  ShieldCheck,
  ArrowRight,
  ExternalLink,
  Sparkles,
  Lock
} from 'lucide-react';
import { useCRM } from '../../context/CRMContext';
import { SwiftMyndLogo } from '../common/SwiftMyndLogo';

interface EmployeeLoginPageProps {
  onSuccessLogin?: () => void;
  onBackToLanding?: () => void;
}

export const EmployeeLoginPage: React.FC<EmployeeLoginPageProps> = ({ onSuccessLogin, onBackToLanding }) => {
  const { team, loginUser, triggerDailyDigest, brandConfig } = useCRM();

  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    const cleanUser = usernameInput.trim().toLowerCase();
    const cleanPass = passwordInput.trim();

    const targetUser = team.find(
      m =>
        (m.username.toLowerCase() === cleanUser ||
          m.email.toLowerCase() === cleanUser ||
          (cleanUser === 'admin' && (m.accessLevel === 'admin' || m.id === 'user-1'))) &&
        (m.password === cleanPass ||
          (m.accessLevel === 'admin' && (cleanPass === 'Admin@Swift2026' || cleanPass === 'admin' || cleanPass === '8899')))
    );

    if (targetUser) {
      setSuccessMsg(`أهلاً بك، ${targetUser.name}! جاري الدخول للمنظومة...`);
      loginUser(targetUser);

      setTimeout(() => {
        // Trigger Daily Digest if employee
        if (targetUser.accessLevel !== 'admin') {
          triggerDailyDigest(targetUser);
        }

        // Update URL to /
        if (typeof window !== 'undefined' && window.history) {
          window.history.pushState({}, '', '/');
        }

        if (onSuccessLogin) {
          onSuccessLogin();
        }
      }, 600);
    } else {
      setIsSubmitting(false);
      setErrorMsg('اسم المستخدم أو كلمة المرور غير صحيحة. يرجى التحقق من صحة البيانات والمحاولة مجدداً.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-[#0f172a] to-slate-900 text-slate-100 flex flex-col justify-between p-4 sm:p-8 selection:bg-blue-600 selection:text-white">
      {/* Top Header */}
      <header className="max-w-5xl w-full mx-auto flex items-center justify-between py-3">
        <div className="flex items-center">
          <SwiftMyndLogo
            variant="full"
            size="md"
            isDark={true}
            showSubtitle={true}
            allowAdminEdit={false}
          />
        </div>

        {/* Back to landing */}
        {onBackToLanding && (
          <button
            onClick={onBackToLanding}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
          >
            <span>الرئيسية التعريفية</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </header>

      {/* Main Login Card */}
      <main className="max-w-md w-full mx-auto my-auto py-8">
        <div className="bg-white/95 text-slate-900 rounded-3xl shadow-2xl border border-slate-100 p-6 sm:p-8 backdrop-blur-md relative overflow-hidden animate-in fade-in zoom-in-95">
          {/* Top subtle decorative strip */}
          <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-500" />

          {/* Heading */}
          <div className="text-center space-y-2 mb-6">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-2xl mx-auto flex items-center justify-center shadow-md shadow-blue-500/20">
              <Lock className="w-7 h-7" />
            </div>

            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              تسجيل الدخول للمنظومة
            </h1>
            <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
              أدخل اسم المستخدم وكلمة المرور الخاصة بحسابك للوصول إلى لوحة العمل والمهام
            </p>
          </div>

          {/* Status Messages */}
          {errorMsg && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-extrabold text-slate-700 mb-1.5">
                اسم المستخدم (اليوزر) أو البريد الإلكتروني:
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  autoFocus
                  autoComplete="username"
                  value={usernameInput}
                  onChange={e => setUsernameInput(e.target.value)}
                  placeholder="مثال: ahmed.sherif أو sara.mansoor"
                  className="w-full pl-3 pr-10 py-3 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 focus:border-blue-600 rounded-xl text-xs font-mono text-slate-900 transition-all outline-none"
                />
                <User className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-extrabold text-slate-700 mb-1.5">
                كلمة المرور (الباسورد):
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={passwordInput}
                  onChange={e => setPasswordInput(e.target.value)}
                  placeholder="أدخل كلمة المرور..."
                  className="w-full pl-10 pr-10 py-3 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 focus:border-blue-600 rounded-xl text-xs font-mono text-slate-900 transition-all outline-none"
                />
                <KeyRound className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3.5 top-3.5 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                  title={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-extrabold rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer text-xs mt-2 disabled:opacity-50"
            >
              <LogIn className="w-4 h-4" />
              <span>{isSubmitting ? 'جاري التحقق...' : 'تسجيل الدخول للمنظومة'}</span>
            </button>
          </form>

          {/* Admin Credentials Helper Box */}
          <div className="mt-5 p-3.5 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/80 rounded-2xl text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-blue-900 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                <span>بيانات دخول الأدمن (المدير العام):</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  setUsernameInput('hadeer.admin');
                  setPasswordInput('Admin@Swift2026');
                }}
                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-bold cursor-pointer transition-all shadow-2xs"
              >
                تعبئة تلقائية الآن ⚡
              </button>
            </div>

            <div className="bg-white/80 p-2 rounded-xl border border-blue-100/80 space-y-1 font-mono text-[11px] text-slate-800">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-sans">اليوزر:</span>
                <span className="font-bold text-blue-700 selection:bg-blue-200">hadeer.admin</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-sans">الباسورد:</span>
                <span className="font-bold text-indigo-700 selection:bg-indigo-200">Admin@Swift2026</span>
              </div>
              <div className="text-[10px] text-slate-400 font-sans pt-1 border-t border-slate-100 flex justify-between">
                <span>أو يمكنك كتابة:</span>
                <span className="text-slate-600 font-mono">admin / admin</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-5xl w-full mx-auto text-center py-3 text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-800/60">
        <span>© {new Date().getFullYear()} {brandConfig.brandName || 'SWIFTMYND'} - كافة الحقوق محفوظة</span>
        <span className="font-mono text-slate-400">بوابة الدخول الآمنة</span>
      </footer>
    </div>
  );
};
